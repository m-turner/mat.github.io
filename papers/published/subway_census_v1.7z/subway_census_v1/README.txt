**********************************
Sources of the subway census data:
**********************************


\station_points and \route_maps
-------------------------------
These are the subway data used in `Subways and urban growth: Evidence from Earth', Gonalez-Navarro and Turner, JUE 2018. Compiled manually by Farhan Yahya, Mahdy Saddradini, Mohamed Salat and Fern Ramoutar between Jan 2012-Feb 2014.  

-Step 1 -Create a list of all subway stations worldwide with continent, country, city name, station name, line name, dummy for terminal station, 
         dummy for transfer station, dummy for loop line, opening date. 
	-Time span: Any subway station built up to 2010 December.
	-Geographical coverage: Worldwide.
	-Sources of information: http://www.urbanrail.net/ and links therein as well as links in wikipedia. 
	-Definition of subway: -Any electrified rail line with no interactions with vehicular or pedestrian traffic. 
			       -Diesel powered suburban rail, and lines with at grade crossings (such as tram or light rail systems) were ignored.			       
    			       -If only subsections of lines satisfied the definition above, we only took into account those portions as subways.
                               -For example: The SanFrancisco Muni is partially underground (satisfies definition) and partially above ground with interactions with vehicles (we ignore sections above ground).

-Step 2 -In google maps, visually see the station and obtain coordinates (lat and long) for each station.

-Step 3 -Create shapefile of subway station points in 2010 with attributes "subway_stations2.shp"

-Step 4 -Create historical series of shortest linear path maps of subway lines between stations "subway_map_YYYY.shp"

\ridership_data
----------------
These are the ridership data used in `Subways and urban growth: Evidence from Earth', Gonalez-Navarro and Turner, JUE 2018.  Details about their construction are provided in the paper. 
